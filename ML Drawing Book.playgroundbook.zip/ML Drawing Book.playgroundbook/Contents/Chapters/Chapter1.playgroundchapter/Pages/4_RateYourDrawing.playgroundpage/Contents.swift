//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # Practice makes the master!
 ### Let's try to refine your art of drawing.

 - Note:
 By setting a `focusAnimal` you can concentrate on a special animal while drawing and the computer will rate it.
 
 */

let bookPage = BookPage()

//#-code-completion(identifier, show, elephant, dolphin, giraffe, octopus, snail, turtle, .)
let prediction = Prediction()

let animalToDraw: AnimalType = /*#-editable-code*/.elephant/*#-end-editable-code*/
prediction.focusAnimal = animalToDraw


/*:
 * Experiment:
 Modify `animalToDraw` and try to draw another animal from the zoo:
 
    - 🐘 -> .elephant
    - 🐬 -> .dolphin
    - 🦒 -> .giraffe
    - 🐙 -> .octopus
    - 🐌 -> .snail
    - 🐢 -> .turtle
 
    ![Image could not be loaded.](exampleDrawings.jpg)
    If you set `animalToDraw` to `nil`, the prediction will focus on all animals again.
 
 */

bookPage.prediction = prediction


//:[< Previous page](@previous) | [Customize your canvas](2_FirstSteps)
//#-hidden-code
// Will be called when the aspired milestone has been reached by the user.
func milestoneReached() {
    
    if let animalToDraw = prediction.focusAnimal {

            PlaygroundPage.current.assessmentStatus = .pass(message: "### Beautiful! Your **\(animalToDraw.asName)** looks fantastic!\n When you're done drawing, tap the cross in the upper right corner to draw another \(animalToDraw.asName) or [**tap here**](@next) to continue.")
    }
    

    
}

let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .focusAnimalRecognized

PlaygroundPage.current.liveView = viewController
//#-end-hidden-code
