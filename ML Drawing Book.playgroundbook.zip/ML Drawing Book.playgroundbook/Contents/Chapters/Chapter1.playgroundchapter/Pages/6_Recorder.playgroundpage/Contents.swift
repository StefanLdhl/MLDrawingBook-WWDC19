//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # Mom, look!
 ### Yes honey, I'll catch it on video!

 - Note:
 Add a `Recorder` to your book page to record your drawing. Run your code and tap the ●-button at the bottom right and start drawing.
 
    Replay your drawing and keep an eye on the bars. Analyze how they change while drawing to improve yourself with every record.
 */
let bookPage = BookPage()

let recorder = Recorder()

// Possibility to start the rec. right at the beginning
//#-code-completion(identifier, show, true, false)
recorder.autoStart = /*#-editable-code*/false/*#-end-editable-code*/


bookPage.recorder = recorder
bookPage.prediction = Prediction()


//:[< Previous page](@previous) | [Customize your canvas](2_FirstSteps)
//#-hidden-code
// Used to determine when the page is successfully completed
func milestoneReached() {

    PlaygroundPage.current.assessmentStatus = .pass(message: "### Congrats!\nYour drawing has been recorded! Tap the play button and see what happens. If you're done [**tap here**](@next) to continue.")
}


let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .drawingRecorded
PlaygroundPage.current.liveView = viewController
//#-end-hidden-code
