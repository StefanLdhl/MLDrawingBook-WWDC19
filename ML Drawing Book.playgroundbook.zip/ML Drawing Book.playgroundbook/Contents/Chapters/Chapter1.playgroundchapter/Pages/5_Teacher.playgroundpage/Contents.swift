//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # The finishing touch.
 ### Learn from the pros by setting up a teacher.

 - Note:
 Adding a `Teacher` to your `BookPage` makes it easier to get started with the drawing. A teacher draws an animal according to your wishes.
    How much of the picture should the teacher draw for you? Decide yourself by setting the `progress`.
 
    **When the teacher is done, it's your turn. - You can complete the drawing.**
 */

let bookPage = BookPage()

//#-code-completion(identifier, show, elephant, dolphin, giraffe, octopus, snail, turtle, .)
let teacher = Teacher()

//Specifies which animal the teacher should draw.
teacher.species = /*#-editable-code*/.elephant/*#-end-editable-code*/

//Indicates how much the teacher should draw (0.0 - 1.0).
teacher.progress = /*#-editable-code*/0.7/*#-end-editable-code*/

//#-code-completion(identifier, show, fast, normal, slow, .)
//Specifies how fastly the teacher should draw.
teacher.speed = /*#-editable-code*/.fast/*#-end-editable-code*/


let prediction = Prediction()
prediction.focusAnimal = teacher.species

bookPage.teacher = teacher
bookPage.prediction = prediction

//:[< Previous page](@previous) | [Customize your canvas](2_FirstSteps)
//#-hidden-code

// Used to determine when the page is successfully completed
func milestoneReached() {
    
     PlaygroundPage.current.assessmentStatus = .pass(message: "### \"It's Not How You Start, It's How You Finish\"\nSo try to complete the drawing now. I suppose it will be an \(teacher.species), right?  😏 When you have finished drawing [**tap here**](@next) to continue.")
    

}

let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .firstUseOfTeacher
PlaygroundPage.current.liveView = viewController
//#-end-hidden-code
