//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # Welcome to your personal ML Drawing Book!
 _🙋‍♂️ Hello, what does ML stand for?_
 
 ML is short for **Machine Learning**. This book is all about it! Your algorithm analyzes your drawings and recognize them in realtime just within seconds. Exciting, isnt't it?
 
 I kicked off with about 250 drawings I recorded on the iPad. Then I trained the ML model by flipping each of the images four times (**image augmentation**).

 ![Image could not be loaded.](MLAlgorithm.jpg)

  Finally I started out with over 1000 images in this colorful drawing book...
 
 
 # Let's get started!
 An artist needs the right environment to let his creativity run free. So let's set up your atelier first.
 
 - Note:
 Everything starts with a blank `BookPage`. Customize it as you like. Execute the code to save your presets. Use your finger or Pencil to start drawing.
 
    🔔 Please turn up the volume to listen to the background music I created in GarageBand.

 */

let bookPage = BookPage()


//The color of your canvas frame.
bookPage.frameColor = /*#-editable-code*/#colorLiteral(red: 0.1333333333, green: 0.4588235294, blue: 0.662745098, alpha: 1)/*#-end-editable-code*/

// The background color of the page.
bookPage.backgroundColor = /*#-editable-code*/#colorLiteral(red: 0.862745098, green: 0.2588235294, blue: 0.2588235294, alpha: 1)/*#-end-editable-code*/
//#-code-completion(identifier, show, drawings, apple, wwdc19, .)

//The overlay of the page background.
bookPage.backgroundPattern = /*#-editable-code*/.drawings/*#-end-editable-code*/

/*:
 - Important:
    💡 **Don't forget to run your code to save the presets!**
 */
//#-hidden-code

// Will be called when the aspired milestone has been reached by the user.
func milestoneReached() {
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Beautiful!\nYour canvas looks fantastic! If you're done admiring it, [**tap here**](@next).")

}

let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .bookPageStarted
PlaygroundPage.current.liveView = viewController

//#-end-hidden-code

