//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # “In drawing, nothing is better than the first attempt." - Pablo Picasso
 ### Go ahead and see what happens!
 
 - Note:
 By adding a `Prediction` to a page, your drawing will be analyzed in real time and you will receive a prediction immediately.
 If you like, you can also change the colors of the prediction bars.
 
    Try to draw one of these animals
 
    - 🐘 Elephant
    - 🐬 Dolphin
    - 🦒 Giraffe
    - 🐙 Octopus
    - 🐌 Snail
    - 🐢 Turtle
 
     ![Image could not be loaded.](exampleDrawings.jpg)
 
 */

let bookPage = BookPage()

//#-code-completion(identifier, show, elephant, dolphin, giraffe, octopus, snail, turtle, nil, .)
let prediction = Prediction()

//Line-color of the main graph.
prediction.mainGraphColor = /*#-editable-code*/#colorLiteral(red: 0.1333333333, green: 0.4588235294, blue: 0.662745098, alpha: 1)/*#-end-editable-code*/

//Line-color of the the outer graphs.
prediction.secondaryGraphColor = /*#-editable-code*/#colorLiteral(red: 0.1333333333, green: 0.4588235294, blue: 0.662745098, alpha: 1)/*#-end-editable-code*/

//Trackline-color of all three graphs.
prediction.trackGraphColor = /*#-editable-code*/#colorLiteral(red: 0.862745098, green: 0.2588235294, blue: 0.2588235294, alpha: 1)/*#-end-editable-code*/

//Adds the prediction to the book page.
bookPage.prediction = prediction

/*:
 - Important:
 💡 **Don't forget to run your code to save the presets!**
 */

//:[< Previous page](@previous) | [Customize your canvas](2_FirstSteps)
//#-hidden-code
// Will be called when the aspired milestone has been reached by the user.
func milestoneReached() {
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### I'm lost for words! This looks great!\nHave you seen how the bars have changed while drawing? You can finish your drawing or modify your code again, otherwise [**tap here**](@next) to continue.")
    
}

let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .firstDrawingCompleted

PlaygroundPage.current.liveView = viewController
//#-end-hidden-code
