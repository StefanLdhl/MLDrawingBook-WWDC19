//#-hidden-code
//#-code-completion(everything, hide)
import PlaygroundSupport
import UIKit
//#-end-hidden-code
/*:
 # Now you know how to do it. Get started!
 
 - Note:
 Use `Prediction`, `Teacher` and `Recorder` to create your perfect drawing studio. **You are the boss!**
 
    🤫 Here again our cheat sheet:
 
    ![Image could not be loaded.](exampleDrawings.jpg)
 
 */
//#-code-completion(everything, show)
//#-editable-code

//:### BookPage
let bookPage = BookPage()
bookPage.frameColor = #colorLiteral(red: 0.9589396119, green: 0.9643107057, blue: 0.9775627255, alpha: 1)
bookPage.backgroundColor = #colorLiteral(red: 0.07058823529, green: 0.1019607843, blue: 0.1843137255, alpha: 1)
bookPage.backgroundPattern = .wwdc19


//:### Prediction
let prediction = Prediction()
//prediction.focusAnimal = .octopus
prediction.mainGraphColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
prediction.secondaryGraphColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
prediction.trackGraphColor = #colorLiteral(red: 0.07058823529, green: 0.1019607843, blue: 0.1843137255, alpha: 1)
prediction.graphLineWidth = 4.0


//:### Teacher
let teacher = Teacher()
teacher.species = .octopus
teacher.progress = 0.45
teacher.speed = .fast


//:### Recorder
let recorder = Recorder()



bookPage.teacher = teacher
bookPage.prediction = prediction
bookPage.recorder = recorder
//#-end-editable-code

//#-hidden-code
// Used to determine when the page is successfully completed
func milestoneReached() {
    
    PlaygroundPage.current.assessmentStatus = .pass(message: "### Thanks for stopping by!\nThis is the last page, so it's time to say goodbye now... Cheers!")
}


let viewController = DrawingStudioViewController.instantiateFromStoryboard()
viewController.currentPage = bookPage
viewController.aspiredMilestoneReached = milestoneReached
viewController.aspiredMilestone = .bookPageStarted
PlaygroundPage.current.liveView = viewController
//#-end-hidden-code
