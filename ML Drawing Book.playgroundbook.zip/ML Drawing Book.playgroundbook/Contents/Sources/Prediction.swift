//
//  Prediction.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation
import UIKit

public class Prediction {
    
    /// The focused animal when predicitonMode is on "focus"
    public var focusAnimal:AnimalType?
    
    /// The color of the progress layer for graph 1
    public var mainGraphColor: UIColor {
        
        didSet {
            //store value
            PresetsManager.store(value: mainGraphColor.convertToHexString(), for: PresetStoreKeys.predictionMainColor)
        }
    }
    
    /// The color of the progress layer for graph 2 & 3
    public var secondaryGraphColor: UIColor {
        didSet {
            //store value
            PresetsManager.store(value: secondaryGraphColor.convertToHexString(), for: PresetStoreKeys.predictionSecondaryColor)
        }
    }
    
    /// The color of the track layer for graph 1, 2 & 3
    public var trackGraphColor: UIColor {
        didSet {
            //store value
            PresetsManager.store(value: trackGraphColor.convertToHexString(), for: PresetStoreKeys.predictionTrackColor)
        }
    }
    
    /// The width of the track/progress line layer for graph 1, 2 & 3
    public var graphLineWidth: CGFloat = 4.0
    
    // MARK: Initialization
    public init() {
        
        //Loading presets, if available
        
        if let storedMainGraphColorHEXValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.predictionMainColor) {
            self.mainGraphColor = UIColor.init(hexStringValue: storedMainGraphColorHEXValue)
        } else {
            self.mainGraphColor = #colorLiteral(red: 0.862745098, green: 0.2588235294, blue: 0.2588235294, alpha: 1)
        }
        
        if let storedSecondaryGraphColorHEXValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.predictionSecondaryColor) {
            self.secondaryGraphColor = UIColor.init(hexStringValue: storedSecondaryGraphColorHEXValue)
        } else {
            self.secondaryGraphColor = #colorLiteral(red: 0.1333333333, green: 0.4588235294, blue: 0.662745098, alpha: 1)
        }
        
        if let storedTrackGraphColorHEXValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.predictionTrackColor) {
            self.trackGraphColor = UIColor.init(hexStringValue: storedTrackGraphColorHEXValue)
        } else {
            self.trackGraphColor = #colorLiteral(red: 0.292470932, green: 0.2925258279, blue: 0.2924636602, alpha: 0.1219465229)
        }
        
    }
    
}

