//
//  Template.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation

public class Template {
    
    private var pathData: [[String]] = [[]]
    private var pathCurvesCount: Int = 0
    private var sourceSideLength: Int = 0
    private var species: AnimalType
    
    // MARK: Initialization
    public init(type: AnimalType) {
        self.species = type
        
    }

    public init(pathData: [[String]], pathCurvesCount: Int, sideLength: Int, species: AnimalType) {
        self.species = species
        self.pathData = pathData
        self.pathCurvesCount = pathCurvesCount
        self.sourceSideLength = sideLength
    }
    
    
    /**
     Fills template with data from plist file.
     */
    public func loadPlistData(completion: @escaping (String?) -> ()) {
        
        
        guard let fileURL = Bundle.main.url(forResource: ("\(species.draftPath)"), withExtension: "plist") else {
            completion("Failed")
            return
        }
        
        do {
            let data = try Data(contentsOf: fileURL)
            guard let plist = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String:Any] else {
                completion("Failed")
                return
            }
            
            guard let pathParts = plist["data"] as? [[String]], let size = plist["size"] as? Int, let curves = plist["curves"] as? Int else {
                completion("Failed")
                return
            }
            
            self.pathData = pathParts
            self.pathCurvesCount = curves
            self.sourceSideLength = size
            
            if pathData.count == 0 {
                pathData.append([])
            }
            
            completion(nil)
            
        }
            
        catch {
            
            completion(error.localizedDescription)
            return
        }
        
    }
    
    /// Returns PathData.
    public func getPathData() -> [[String]] {
        return pathData
    }
    
    /// Returns PathCurvesCount.
    public func getPathCurvesCount() -> Int {
        return pathCurvesCount
    }
    
    /// Returns SourceSideLength.
    public func getSourceSideLength() -> Int {
        return sourceSideLength
    }
    
    
    
}



