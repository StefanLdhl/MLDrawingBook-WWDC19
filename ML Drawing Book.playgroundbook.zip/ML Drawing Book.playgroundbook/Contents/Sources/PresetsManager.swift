//
//  PresetsManager.swift
//  LiveViewTestApp
//
//  Created by Stefan Liesendahl on 21.03.19.
//

import Foundation
import PlaygroundSupport

///Wrapper for PlaygroundKeyValueStore
class PresetsManager {
    
    /**
     Retrieves the value for a specific key from current PlaygroundKeyValueStore.
     
     - Parameters:
        - key: the associated key.
     
     */
    static func getStoredStringFor(key: PresetStoreKeys) -> String? {
        
        if let keyValue = PlaygroundKeyValueStore.current[key.rawValue],
            case .string(let value) = keyValue {
            
            return value
            
        }
        
        return nil
    }
    
    /**
     Stores a value into PlaygroundKeyValueStore.
     
     - Parameters:
        - key: the associated key for PlaygroundKeyValueStore.
        - value: value to save in PlaygroundKeyValueStore.
     
     */
    static func store(value:String, for key: PresetStoreKeys) {
    
        PlaygroundKeyValueStore.current[key.rawValue] =  PlaygroundValue.string(value)

    }
    
}

///Contains all possible keys for PlaygroundKeyValueStore
enum PresetStoreKeys: String {
    case pageBackgroundColor = "userPresets_pageBackgroundColor"
    case pageFrameColor = "userPresets_pageFrameColor"
    case pageBackgroundPattern = "userPresets_pageBackgroundPattern"
    case predictionMainColor = "userPresets_predictionMainGraphColor"
    case predictionSecondaryColor = "userPresets_predictionSecondaryGraphColor"
    case predictionTrackColor = "userPresets_predictionTrackGraphColor"
    
}
