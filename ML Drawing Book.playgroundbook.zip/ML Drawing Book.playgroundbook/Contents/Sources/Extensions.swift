//
//  Extensions.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 20.03.19.
//

import Foundation
import UIKit

extension CGPoint {
    
    /**
     Adjusts the oriigin of the point in proportion to the new frame.
     
     - Parameters:
        - fromSize: current size
        - toSize: target size
     
     */
    mutating func convertFrameSideLength(from fromSize: CGFloat, to toSize: CGFloat) {
        
        let factor = toSize / fromSize
        
        self.x *= factor
        self.y *= factor
        
    }
    
    /**
     Returns the midPoint between itself and point2.
     
     - Parameters:
        - point2: the endpoint
     
     */
    func getMidPointTo(point2:CGPoint)->CGPoint {
        
        let x=(self.x + point2.x)/2
        let y=(self.y + point2.y)/2
        return CGPoint(x: x, y: y)
    }
    
    
}

extension UIColor {
    
    /**
     Initalizes UIColor from HEX string.
     
     - Parameters:
     - hexStringValue: the hex string (# + 6 characters).
     
     */
    convenience init(hexStringValue: String) {
        
        if hexStringValue.count == 7 {
        let hex = hexStringValue.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var intValue = UInt32()
        Scanner(string: hex).scanHexInt32(&intValue)
        self.init(red: CGFloat(intValue >> 16) / 255, green: CGFloat(intValue >> 8 & 0xFF) / 255, blue: CGFloat(intValue & 0xFF) / 255, alpha: 1)
        } else {
            
            self.init(cgColor: UIColor.gray.cgColor)
        }
    }
    
    
    ///Converts UIColor to String.
    func convertToHexString() -> String {
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        let colorInRGB: Int = (Int)(red*255)<<16 | (Int)(green*255)<<8 | (Int)(blue*255)<<0
        
        return String(format:"#%06x", colorInRGB)
    }
    
}



