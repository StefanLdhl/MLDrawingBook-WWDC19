//
//  Teacher.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation

public class Teacher {
    
    /// The drawing progress of the teacher
    public var progress = 1.0
    
    /// The animal type for this page
    public var species: AnimalType = .elephant
    
    /// The drawing speed of the teacher
    public var speed: DrawingSpeed = .normal
    
    
    // MARK: Initialization
    public init() {}
    
}

public enum DrawingSpeed : Double {
    case fast = 0.004
    case normal = 0.008
    case slow = 0.02
    
}



