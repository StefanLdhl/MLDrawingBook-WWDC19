//
//  PredictionGraph.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 17.03.19.
//

import UIKit


class PredictionGraph: UIView {
    
    
    ///Color of the progress line in graph
    public var progressLineColor: UIColor = .red {
        didSet{
            progressLayer.strokeColor = progressLineColor.cgColor
        }
    }
    
    ///Color of the track line in graph
    public var trackLineColor: UIColor = .gray {
        didSet{
            trackLayer.strokeColor = trackLineColor.cgColor
        }
    }
    
    ///Width of the progress/track line in graph
    public var lineWidth: CGFloat = 5 {
        didSet{
            
            if lineWidth > 10 {lineWidth = 10}
            
            trackLayer.lineWidth = lineWidth
            progressLayer.lineWidth = lineWidth
            
        }
    }
    
    ///Animation speed of the progress line in graph
    public var progressLineAnimationSpeed: Int = 50
    
    
    private let progressLayer = CAShapeLayer()
    private let trackLayer = CAShapeLayer()
    private var lastProgressValue: CGFloat = 0.0
    private var lastPrecictedAnimalType: AnimalType = .elephant
    
    private var progressPath = UIBezierPath()
    private var animalLabel = UILabel()
    private var percentLabel = UILabel()
    
    private var radius: CGFloat {
        get{
            
            let possibleRadius = (self.bounds.size.width - lineWidth) / 2
            
            if possibleRadius > self.bounds.size.height {
                return self.bounds.size.height - lineWidth
            }
            return possibleRadius
            
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        setupGraph()
        setupLabel()
        
    }
    
    
    /**
     Updates the prediction value (progress) of the graph.
     
     - Parameters:
        - prediction: the new predictive value.
        - animal: the animal associated with this prediction.
     
     */
    public func setPrediction(prediction: CGFloat, for animal:AnimalType) {
        
        
        if lastPrecictedAnimalType != animal {
            lastProgressValue = 0.0
        }
        
        lastPrecictedAnimalType = animal
        
        animateProgress(to: prediction, duration: CFTimeInterval(self.progressLineAnimationSpeed/100))
        
        
        UIView.transition(with: animalLabel,
                          duration: 0.25,
                          options: .transitionCrossDissolve,
                          animations: {
                            self.animalLabel.text = ("\(animal.asEmoji)")
        }, completion: nil)
        
        UIView.transition(with: percentLabel,
                          duration: 0.25,
                          options: .transitionCrossDissolve,
                          animations: {
                            self.percentLabel.text = ("\(Int(round(prediction*100))) %")
        }, completion: nil)
        
        
        
    }
    
    
    /**
     Fills the labels with placeholder data
     
     - Parameters:
        - emoji: placeholder for the animal label.
        - animal: placeholder for the percent label.
     
     */
    public func setPlaceholder(emoji: String, text: String) {
        
        
        UIView.transition(with: percentLabel,
                          duration: 0.25,
                          options: .transitionCrossDissolve,
                          animations: {
                            self.percentLabel.text = text
        }, completion: nil)
        
        
        UIView.transition(with: animalLabel,
                          duration: 0.25,
                          options: .transitionCrossDissolve,
                          animations: {
                            self.animalLabel.text = emoji
        }, completion: nil)
        
    }
    
    
    /**
     Adds the label to the view
     */
    private func setupLabel() {
        
        let percentLabelHeight: CGFloat = 10.0
        
        //animalLabel.frame = progressPath.bounds.insetBy(dx: lineWidth, dy: percentLabelHeight)
        animalLabel.frame = progressPath.bounds.inset(by: UIEdgeInsets(top: lineWidth, left: lineWidth, bottom: percentLabelHeight, right: lineWidth))
        
        animalLabel.textAlignment = .center
        animalLabel.font = UIFont.systemFont(ofSize: 30)
        animalLabel.minimumScaleFactor = 0.01
        animalLabel.adjustsFontSizeToFitWidth = true
        animalLabel.lineBreakMode = .byClipping
        animalLabel.numberOfLines = 0
        
        percentLabel.frame = CGRect.init(x: progressPath.bounds.origin.x, y: self.bounds.height-percentLabelHeight, width: progressPath.bounds.width, height: percentLabelHeight)
        percentLabel.textAlignment = .center
        percentLabel.minimumScaleFactor = 0.01
        percentLabel.adjustsFontSizeToFitWidth = true
        percentLabel.lineBreakMode = .byClipping
        percentLabel.numberOfLines = 0
        percentLabel.font = UIFont.boldSystemFont(ofSize: percentLabelHeight)
        self.addSubview(percentLabel)
        self.addSubview(animalLabel)
    }
    
    
    /**
     Creates the path and draws the layers
     */
    private func setupGraph(){
        
        progressLayer.removeFromSuperlayer()
        trackLayer.removeFromSuperlayer()
        
        progressPath = UIBezierPath.init(arcCenter: CGPoint(x: self.bounds.size.width / 2, y: self.bounds.size.height), radius: radius, startAngle: .pi, endAngle: 0.0, clockwise: true)
        
        self.progressLayer.fillColor = UIColor.clear.cgColor
        self.progressLayer.strokeColor = progressLineColor.cgColor
        self.progressLayer.lineWidth = lineWidth
        self.progressLayer.lineCap = CAShapeLayerLineCap.round
        self.progressLayer.path = progressPath.cgPath
        
        self.trackLayer.fillColor = UIColor.clear.cgColor
        self.trackLayer.strokeColor = trackLineColor.cgColor
        self.trackLayer.lineWidth = lineWidth
        self.trackLayer.lineCap = CAShapeLayerLineCap.round
        self.trackLayer.path = progressPath.cgPath
        
        
        self.layer.addSublayer(trackLayer)
        self.layer.addSublayer(progressLayer)
        
        animateProgress(to: 0, duration: 0)   }
    
    
    /**
     Starts the animation of the Progress Layer
     
     - Parameters:
        - progress: the new predictive value as progress.
        - duration: duration of the animation.
     
     */
    private func animateProgress(to progress: CGFloat, duration: CFTimeInterval) {
        
        let progressAnimation = CABasicAnimation(keyPath: "strokeEnd")
        progressAnimation.duration = duration
        progressAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        progressAnimation.fromValue = lastProgressValue
        progressAnimation.fillMode = .forwards
        progressAnimation.isRemovedOnCompletion = false
        progressAnimation.toValue = progress
        
        progressLayer.add(progressAnimation, forKey: "progressAnimation")
        lastProgressValue = progress
        
    }
    
    
    
}

