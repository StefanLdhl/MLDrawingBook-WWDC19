//
//  BookPage.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation
import UIKit
import PlaygroundSupport

public class BookPage {
    
    /// The frame color of the canvas.
    public var frameColor: UIColor {
        didSet {
            //store value
            PresetsManager.store(value: frameColor.convertToHexString(), for: PresetStoreKeys.pageFrameColor)
        }
    }
    
    /// The background color for this page.
    public var backgroundColor: UIColor {
        didSet {
            //store value
            PresetsManager.store(value: backgroundColor.convertToHexString(), for: PresetStoreKeys.pageBackgroundColor)
        }
    }
    
    /// The background pattern for this page.
    public var backgroundPattern: BackgroundPattern {
        
        didSet {
            //store value
            PresetsManager.store(value: backgroundPattern.rawValue, for: PresetStoreKeys.pageBackgroundPattern)
        }
    }
    
    
    /// Optional teacher for this page.
    public var teacher: Teacher?
    
    /// Optional recorder for this page.
    public var recorder: Recorder?
    
    /// Optional prediction including the prediciton mode for this page.
    public var prediction: Prediction?
    
    // MARK: Initialization
    public init() {
        
        //Loading presets, if available
        
        if let storedBackgroundColorHEXValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.pageBackgroundColor) {
            self.backgroundColor = UIColor.init(hexStringValue: storedBackgroundColorHEXValue)
        } else {
            self.backgroundColor = #colorLiteral(red: 0.862745098, green: 0.2588235294, blue: 0.2588235294, alpha: 1)
        }
        
        if let storedFrameColorHEXValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.pageFrameColor) {
            self.frameColor = UIColor.init(hexStringValue: storedFrameColorHEXValue)
        } else {
            self.frameColor = #colorLiteral(red: 0.1333333333, green: 0.4588235294, blue: 0.662745098, alpha: 1)
        }
        
        if let storedBackgroundPatternRawValue = PresetsManager.getStoredStringFor(key: PresetStoreKeys.pageBackgroundPattern) {
            self.backgroundPattern = BackgroundPattern.init(rawValue: storedBackgroundPatternRawValue) ?? .drawings
        } else {
            self.backgroundPattern = .drawings
        }
        
        
    }
    
}


public enum BackgroundPattern: String {
    case apple = "wallpaper_apple.png"
    case drawings = "wallpaper_drawings.png"
    case wwdc19 = "wallpaper_wwdc19.png"
}





