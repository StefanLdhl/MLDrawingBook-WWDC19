//
//  Animal.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation

public enum AnimalType : String {
    case elephant
    case dolphin
    case giraffe
    case octopus
    case snail
    case turtle
    
    /// Matching emoji for animal type
    public var asEmoji: String {
        switch self {
        case .elephant: return "🐘"
        case .dolphin: return "🐬"
        case .giraffe: return "🦒"
        case .octopus: return "🐙"
        case .snail: return "🐌"
        case .turtle: return "🐢"
        }
    }
    
    /// Real name for animal type
    public var asName: String {
        switch self {
        case .elephant: return "Elephant"
        case .dolphin: return "Dolphin"
        case .giraffe: return "Giraffe"
        case .octopus: return "Octopus"
        case .snail: return "Snail"
        case .turtle: return "Turtle"
            
        }
    }
    
    /// DraftPath for animal type (plist)
    public var draftPath: String {
        switch self {
        case .elephant: return "elephant"
        case .dolphin: return "dolphin"
        case .giraffe: return "giraffe"
        case .octopus: return "octopus"
        case .snail: return "snail"
        case .turtle: return "turtle"
        }
    }
    
    
}

