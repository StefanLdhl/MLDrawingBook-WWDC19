//
//  PaintingArea.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import Foundation
import UIKit

class PaintingArea: UIView {
    
    private let drawPath = UIBezierPath()
    private var lastPoint: CGPoint
    private var lineColor: UIColor = .black
    private var lineWidth: CGFloat = 8.0
    private var pathData: [[String]] = [[]]
    private var pathPartIndex = 0
    private var pathCurvesCount = 0
    private var locked = false
    private var draftTimer = Timer()
    private var canvasSize: CGSize
    
    
    /// Delegate for the canvas.
    public var delegate: PaintingAreaDelegate?
    
    /// Returns true if canvas is completely empty.
    public var isEmpty = true
    
    
    // MARK: Initialization
    override init(frame: CGRect) {
        
        lastPoint = CGPoint.zero
        canvasSize = CGSize()
        
        super.init(frame: frame)
        canvasSize = self.frame.size
    }
    
    required init(coder aDecoder: NSCoder) {
        
        lastPoint = CGPoint.zero
        canvasSize = CGSize()
        
        super.init(coder: aDecoder)!
        canvasSize = self.frame.size
        
        // GestureRecognizer for drawing (lines)
        let drawGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(drawGesture))
        drawGestureRecognizer.maximumNumberOfTouches=1
        self.addGestureRecognizer(drawGestureRecognizer)
        
        // GestureRecognizer for drawing (points)
        let pointGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapGesture))
        pointGestureRecognizer.numberOfTapsRequired = 1
        self.addGestureRecognizer(pointGestureRecognizer)
        
    }
    
    
    /// Clears the canvas and resets variables.
    public func clear() {
        
        isEmpty = true
        pathData = [[]]
        pathPartIndex = 0
        pathCurvesCount = 0
        drawPath.removeAllPoints()
        
        self.draftDone(completed: false)
        
        self.layer.sublayers = nil
        self.setNeedsDisplay()
    }
    
    
    // GestureRecognizer for recognizing points (single tap).
    @objc private func tapGesture(tapGestureRecognizer: UITapGestureRecognizer)->Void
    {
        guard !locked else {
            return
        }
        
        isEmpty = false
        
        if tapGestureRecognizer.state == .ended {
            let currentPoint = tapGestureRecognizer.location(in: self)
            
            //draw path
            drawPath.move(to: currentPoint)
            drawPath.addLine(to: currentPoint)
            
            //save & update status
            pathCurvesCount += 1
            lastPoint = currentPoint
            pathData[pathPartIndex].append(NSCoder.string(for: currentPoint))
            pathPartIndex += 1
            pathData.append([])
            
            self.setNeedsDisplay()
            
            delegate?.canvasChanged()
        }
        
    }
    
    
    // GestureRecognizer for recognizing lines.
    @objc private func drawGesture(drawGestureRecognizer: UIPanGestureRecognizer)->Void
    {
        
        guard !locked else {
            return
        }
        isEmpty = false
        
        let currentPoint = drawGestureRecognizer.location(in: self)
        let midPoint = lastPoint.getMidPointTo(point2: currentPoint)
        
        
        if drawGestureRecognizer.state == .began
        {
            pathData[pathPartIndex].append(NSCoder.string(for: currentPoint))
            drawPath.move(to: currentPoint)
            
            pathCurvesCount += 1
            
        } else if drawGestureRecognizer.state == .changed
        {
            pathData[pathPartIndex].append(NSCoder.string(for: currentPoint))
            drawPath.addQuadCurve(to: midPoint,controlPoint: lastPoint)
            pathCurvesCount += 1
            
        } else if drawGestureRecognizer.state == .ended {
            delegate?.canvasChanged()
            pathPartIndex += 1
            pathData.append([])
        }
        
        lastPoint=currentPoint
        self.setNeedsDisplay()
    }
    
    
    
    override func draw(_ rect: CGRect) {
        // updating the path
        lineColor.setStroke()
        drawPath.stroke()
        drawPath.lineCapStyle = .round
        drawPath.lineWidth=lineWidth
        
    }
    
    
    /**
     Starts the record of the canvas.
     */
    public func startRecord() {
        clear()
    }
    
    /**
     Stops the record of the canvas and returns finished template.
     */
    public func stopRecord (completion: @escaping (Template) -> ()) {
        //create and return new template
        completion(Template(pathData: pathData, pathCurvesCount: pathCurvesCount, sideLength: Int(self.frame.size.width), species: .elephant))
    }
    
    
    
    /**
     Starts the automatic drawing on the canvas from a template.
     
     - Parameters:
        - template: Content to be drawn.
        - teacher: Specifications for drawing.
     */
    public func drawFromTemplate(template: Template,  teacher: Teacher) {
        
        //load data from template & teacher
        pathCurvesCount = template.getPathCurvesCount()
        pathData = template.getPathData()
        pathPartIndex = pathData.count-1
        let size = CGFloat(template.getSourceSideLength())
    
        //number of iterations until stop
        let maxIterations = Int((Double(pathCurvesCount) * teacher.progress).rounded(.down))
        
        //reset canvas
        drawPath.removeAllPoints()
        self.layer.sublayers = nil
        self.setNeedsDisplay()
        locked = true
        lastPoint=CGPoint.zero
        isEmpty = true
        
        
        draftTimer.invalidate()

        
        var currentPointSet = 0
        var currentPoint = 0
        var counter = 0
        
        
        /*
         Format of template pathData [[String]]
         
         pointSet1
            point1
            point2
            point3
            ...
         
         pointSet2
            point1
            point2
            point3
            ...
         
         ...
         */
        
        
        //setup timer
        draftTimer = Timer.scheduledTimer(withTimeInterval: teacher.speed.rawValue, repeats: true) { timer in
            
            if counter >= maxIterations {
                //stop drawing
                self.delegate?.templateDrawingCompleted()
                self.draftDone(completed: true)
            }
            
            if self.pathData.indices.contains(currentPointSet) {
                
                let pointSetContent = self.pathData[currentPointSet]
                
                if pointSetContent.count > 0 {
                    self.isEmpty = false
                    
                    if currentPoint == 0 {
                        //first point in point set
                        counter += 1
                        var start = NSCoder.cgPoint(for: pointSetContent[0])
                        start.convertFrameSideLength(from: size, to: self.frame.width)
                        self.drawPath.move(to: start)
                        self.drawPath.addLine(to: start)
                        
                        self.lastPoint = start
                        currentPoint += 1
                        
                        self.setNeedsDisplay()
                        
                    } else if pointSetContent.indices.contains(currentPoint) {
                        
                        //another point in point set
                        counter += 1
                        var drawingPoint = NSCoder.cgPoint(for: pointSetContent[currentPoint])
                        drawingPoint.convertFrameSideLength(from: size, to: self.frame.width)
                        
                        let midPoint = self.lastPoint.getMidPointTo(point2: drawingPoint)
                        self.drawPath.addQuadCurve(to: midPoint,controlPoint: self.lastPoint)
                        
                        
                        self.lastPoint = drawingPoint
                        self.setNeedsDisplay()
                        currentPoint += 1
                        
                        
                    } else {
                        
                        //no point left in current point set, open next point set
                        currentPoint = 0
                        currentPointSet += 1
                        self.delegate?.canvasChanged()
                        
                        
                    }
                    
                    
                } else {
                    // no point in set -> skipping
                    currentPointSet += 1
                    currentPoint=0
                    
                }
                
                
            } else {
                //no more point in set left
                self.delegate?.templateDrawingCompleted()
                self.draftDone(completed: true)
                
            }
            
        }
        
    }
    
    
    
    ///Stops the timer and unlock canvas.
    private func draftDone(completed: Bool) {
        draftTimer.invalidate()
        self.locked = false
        self.delegate?.canvasChanged()
        
        if completed {
            self.delegate?.templateDrawingCompleted()
        }
    }
    
    
    override func layoutSubviews() {
        updatePath()
        self.draftDone(completed: false)
    }
    
    
    ///Adjusts the size of the drawPath when the source frame changes.
    private func updatePath() {
        
        let newSize = self.frame.size
        
        if newSize != canvasSize {
            
            let scaleWidth = newSize.width / canvasSize.width
            let scaleHeight = newSize.height / canvasSize.height
            
            drawPath.apply(CGAffineTransform(scaleX: scaleWidth, y: scaleHeight))
            self.setNeedsDisplay()
            
            canvasSize = newSize
            
        }
        
        
    }
    
    
    
    
}


protocol PaintingAreaDelegate {
    
    /// Gets called when draw gesture ended.
    func canvasChanged()
    
    /// gets called when an automatic drawing from template ended.
    func templateDrawingCompleted()
}


