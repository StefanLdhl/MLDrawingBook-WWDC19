//
//  MLDrawPredicitionManager.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 17.03.19.
//

import Foundation
import UIKit
import CoreML
import Vision
import ImageIO


struct AnimalTypeRating {
    var type:AnimalType
    var confidence:CGFloat
}

@available(iOS 11.0, *)
class AnimalDrawPredictionManager {
    
    /**
     Starts the prediction process for a canvas
     
     - Parameters:
        - view: associated canvas.
     
     */
    public func prediction(for view: PaintingArea, completion: @escaping ([AnimalTypeRating]) -> ()) {
 
        let image = UIImage.init(view: view)
        
            //Creates a CIImage from the UIImage
            guard let ciImage = CIImage(image: image) else { fatalError("Unable to create \(CIImage.self) from \(image).") }
        
        
            DispatchQueue.global(qos: .userInitiated).async {
                
                do {
                    
                    let handler = VNImageRequestHandler(ciImage: ciImage, orientation: CGImagePropertyOrientation(image.imageOrientation))
                    
                    let animalModel = try VNCoreMLModel(for: AnimalDraw().model)
                    
                    let request = VNCoreMLRequest(model: animalModel, completionHandler: {request, error in
                        
                        if let results = request.results as? [VNClassificationObservation]  {
                            
                            var output:[AnimalTypeRating] = []
                            for entry in results {
                                //Map the results into "AnimalTypeRating" objects
                                if let type = AnimalType(rawValue: entry.identifier) {
                                    output.append(AnimalTypeRating.init(type:type, confidence: CGFloat(entry.confidence)))                                    
                                }
                                
                            }
                            //returns the final array
                            completion(output)
                            
                        } else {
                            
                            completion([])
                            
                        }
                        
                    })
                    
                    request.imageCropAndScaleOption = .centerCrop
    
                    try handler.perform([request])
                    
                } catch {
                    completion([])
                    print("Failed to perform classification.\n\(error.localizedDescription)")
                }
            }
 
    }

}


// https://developer.apple.com/documentation/imageio/cgimagepropertyorientation
extension CGImagePropertyOrientation {
    /**
     Converts a `UIImageOrientation` to a corresponding
     `CGImagePropertyOrientation`. The cases for each
     orientation are represented by different raw values.
     
     - Tag: ConvertOrientation
     */
    init(_ orientation: UIImage.Orientation) {
        switch orientation {
        case .up: self = .up
        case .upMirrored: self = .upMirrored
        case .down: self = .down
        case .downMirrored: self = .downMirrored
        case .left: self = .left
        case .leftMirrored: self = .leftMirrored
        case .right: self = .right
        case .rightMirrored: self = .rightMirrored
        }
    }
}


extension UIImage {
    
    /**
     Returns an UIImage from a UIView
     
     - Parameters:
        - view: associated view.
     
     */
    convenience init (view: UIView){
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0.0)
        defer { UIGraphicsEndImageContext() }
        
        if let context = UIGraphicsGetCurrentContext() {
            view.layer.render(in: context)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            self.init(cgImage: image!.cgImage!)
            
        }
        else {
            self.init()
        }
        
    }
    
}

