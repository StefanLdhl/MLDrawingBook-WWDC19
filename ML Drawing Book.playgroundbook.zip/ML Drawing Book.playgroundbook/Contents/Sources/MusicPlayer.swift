//
//  MusicPlayer.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 21.03.19.
//

import Foundation
import AVFoundation

public var musicPlayer: AVAudioPlayer!


/**
 Starts the background music for the current book page.
 
 - Parameters:
    - songName: name of the song to be played
 
 */
public func startBackgroundSong(songName: String) {
    
    let songUrl = Bundle.main.url(forResource: songName, withExtension: "mp3")
    
    if let url = songUrl {
        do {
            try musicPlayer = AVAudioPlayer(contentsOf: url)
            musicPlayer.numberOfLoops = -1
            musicPlayer.prepareToPlay()
            musicPlayer.play()
        } catch {
            print("Error while playing the background song.")
            return
        }
    }
    
}

