//
//  DrawingStudioViewController.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 18.03.19.
//

import UIKit
import PlaygroundSupport
import SpriteKit
import CoreML
import Vision

@objc(Book_Sources_LiveViewController)
public class DrawingStudioViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer, PaintingAreaDelegate {
    
    //Outlets
    @IBOutlet weak var frameHolder: UIView!
    @IBOutlet weak var paintingArea: PaintingArea!
    @IBOutlet weak var graph1: PredictionGraph!
    @IBOutlet weak var graph2: PredictionGraph!
    @IBOutlet weak var graph3: PredictionGraph!
    @IBOutlet weak var mainPredicitonView: UIView!
    @IBOutlet weak var predictionView1: UIView!
    @IBOutlet weak var predictionView2: UIView!
    @IBOutlet weak var predictionView3: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var wallpaper: UIImageView!
    
    
    private var recordRunning = false
    private var recordedAnimalTemplate: Template?
    private var drawnLinesCounter = 0
    private var aspiredMilestoneAlreadyReached = false
    
    
    /// The associated book page
    public var currentPage = BookPage()
    
    /// The aspired milestone for this session
    public var aspiredMilestone: BookMilestone = .none
    public var aspiredMilestoneReached: (() -> Void)?
    
    
    
    public enum BookMilestone {
        case bookPageStarted
        case firstDrawingCompleted
        case focusAnimalRecognized
        case firstUseOfTeacher
        case drawingRecorded
        case bookCompleted
        case none
    }
    

    public override func viewDidLoad() {
        super.viewDidLoad()
        
        //play background music
        startBackgroundSong(songName: "MLBookFluteBackgroundSong")
        
    
        //set PaintingAreaDelegate
        paintingArea.delegate = self
        
        setupViews()
        self.view.setNeedsLayout()
        
        //For the upper inset in the playground app on iPad
        NSLayoutConstraint.activate([
            mainView.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor),
            mainView.bottomAnchor.constraint(equalTo: liveViewSafeAreaGuide.bottomAnchor)
            ])
    }
    
    
    private func setupViews() {
        
        frameHolder.layer.shadowColor = UIColor.black.cgColor
        frameHolder.layer.shadowOpacity = 0.5
        frameHolder.layer.shadowOffset = CGSize.zero
        frameHolder.layer.shadowRadius = 26
        frameHolder.layer.cornerRadius = 15
        frameHolder.backgroundColor = currentPage.frameColor
        
        paintingArea.layer.cornerRadius = 15
        paintingArea.layer.masksToBounds = true
        
        //Prediciton Views
        predictionView1.layer.cornerRadius = 9
        predictionView1.layer.masksToBounds = true
        predictionView1.layer.borderColor = currentPage.frameColor.cgColor
        predictionView1.layer.borderWidth = 2
        
        predictionView2.layer.cornerRadius = 9
        predictionView2.layer.masksToBounds = true
        predictionView2.layer.borderColor = currentPage.frameColor.cgColor
        predictionView2.layer.borderWidth = 2
        
        predictionView3.layer.cornerRadius = 9
        predictionView3.layer.masksToBounds = true
        predictionView3.layer.borderColor = currentPage.frameColor.cgColor
        predictionView3.layer.borderWidth = 2
        
        
        playButton.alpha = 0.0
        playButton.isUserInteractionEnabled = false
        recordButton.isHidden = currentPage.recorder == nil

        
        self.view.backgroundColor = currentPage.backgroundColor
        wallpaper.image = UIImage.init(named: currentPage.backgroundPattern.rawValue)
        
        
        //Check for prediction
        if let prediction = currentPage.prediction {
            if prediction.focusAnimal != nil {
                predictionView2.isHidden = true
                predictionView3.isHidden = true
            }
            
            graph1.progressLineColor = prediction.mainGraphColor
            graph2.progressLineColor = prediction.secondaryGraphColor
            graph3.progressLineColor = prediction.secondaryGraphColor
            
            graph1.trackLineColor = prediction.trackGraphColor
            graph2.trackLineColor = prediction.trackGraphColor
            graph3.trackLineColor = prediction.trackGraphColor
            
            graph1.lineWidth = prediction.graphLineWidth
            graph2.lineWidth = prediction.graphLineWidth
            graph3.lineWidth = prediction.graphLineWidth
            
            
        } else {
            mainPredicitonView.isHidden = true
        }
        
        
        //Check for teacher
        if let teacher = currentPage.teacher {
            graph1.setPlaceholder(emoji: teacher.species.asEmoji, text: "Teacher")
        }
        
        //Check for recorder auto start
        if let recorder = currentPage.recorder {
            
            if recorder.autoStart {
                paintingArea.startRecord()
                recordRunning = true
                toggleRecordButton()
                updateReplayButton()
                
            }
        }
        
    }
    


    public override func viewDidAppear(_ animated: Bool) {
    
        //Teacher may not start until all subviews have been loaded
        if let teacher = currentPage.teacher {
            let drawTemplate = Template(type: teacher.species)
            drawTemplate.loadPlistData { (error) in
                if error == nil {
                    self.paintingArea.drawFromTemplate(template: drawTemplate, teacher: teacher)
                } else {
                    print("Error starting teacher")
                }
                
            }
            
        } else {
            graph1.setPlaceholder(emoji: "👇", text: "Let's draw!")
        }

        
        userHasReachedMilestone(milestone: .bookPageStarted)

    }
    
    
    @IBAction func clear(_ sender: Any) {

        paintingArea.clear()
        
    }
    
    
    @IBAction func record(_ sender: Any) {
        
        if recordRunning {
            //stop record
            userHasReachedMilestone(milestone: .drawingRecorded)
            paintingArea.stopRecord { (template) in
                
                self.recordedAnimalTemplate = template
                
            }
        } else {
            //start record
            paintingArea.startRecord()
        
        }
        
        recordRunning = !recordRunning
        toggleRecordButton()
        updateReplayButton()
    }
    
    
    @IBAction func replay(_ sender: Any) {
        
        //replay recorded template
        if let recordedAnimalTemplateToDraw = recordedAnimalTemplate {
            graph1.setPlaceholder(emoji: "📺", text: "Replay")
            graph2.setPlaceholder(emoji: "", text: "")
            graph3.setPlaceholder(emoji: "", text: "")
            
            self.paintingArea.drawFromTemplate(template: recordedAnimalTemplateToDraw, teacher: Teacher())
        }
        
    }
    
    
    ///Updates the style, visibility and animation of the record button
    private func toggleRecordButton() {
        
        if recordRunning {
            //record starts
            graph1.setPlaceholder(emoji: "🎥", text: "Recording")
            graph2.setPlaceholder(emoji: "", text: "")
            graph3.setPlaceholder(emoji: "", text: "")
            
            //red button with pulsing animation
            recordButton.setTitleColor(UIColor.red, for: .normal)
            
            if recordButton.layer.animation(forKey: "pulsingAnimation") == nil {
                let pulseAnimation = CABasicAnimation(keyPath: #keyPath(CALayer.opacity))
                pulseAnimation.duration = 0.9
                pulseAnimation.fromValue = 0.2
                pulseAnimation.toValue = 1
                pulseAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
                pulseAnimation.autoreverses = true
                pulseAnimation.repeatCount = .greatestFiniteMagnitude
                self.recordButton.layer.add(pulseAnimation, forKey: "pulsingAnimation")
            }
        } else {
            //record stops
            recordButton.setTitleColor(UIColor.black, for: .normal)
            recordButton.alpha = 0.4
            recordButton.layer.removeAnimation(forKey: "pulsingAnimation")
        }
        
    }
    
    
    ///Updates the style and visibility of the replay button
    private func updateReplayButton() {
        var playButtonAlpha: CGFloat = 0.4
        var playButtonEnabled = true
        
        if recordRunning || recordedAnimalTemplate == nil {
            playButtonAlpha = 0.0
            playButtonEnabled = false
        }
        
        self.playButton.isUserInteractionEnabled = playButtonEnabled
        self.playButton.alpha = playButtonAlpha
        
        DispatchQueue.main.async {
            UIView.transition(with: self.playButton,
                              duration: 0.25,
                              options: .transitionCrossDissolve,
                              animations: {
                                self.playButton.alpha = playButtonAlpha
            }, completion: nil)
        }
    }
    
    
    ///Passes information of a reached milestone back to the playgroundpage
    private func userHasReachedMilestone(milestone: BookMilestone) {
        
        if !aspiredMilestoneAlreadyReached && milestone == aspiredMilestone {
            aspiredMilestoneAlreadyReached = true
            self.aspiredMilestoneReached?()
        }
        
    }
    

    // MARK: PaintingAreaDelegate
    internal func canvasChanged() {
        
        guard !paintingArea.isEmpty else {
            return
        }
        
        drawnLinesCounter += 1
        
        if drawnLinesCounter > 2 {
            userHasReachedMilestone(milestone: .firstDrawingCompleted)
        }
        
        //get prediction using PredictionManager
        if let prediction = currentPage.prediction {
            
            let predictManager = AnimalDrawPredictionManager()
            predictManager.prediction(for: paintingArea) { (results) in
                DispatchQueue.main.async {
                    
                    //focus on choosen animal
                    if let focusAnimal = prediction.focusAnimal {
                        
                        if let ratedFocusAnimal = results.first(where: {$0.type == focusAnimal}) {
                            
                            if self.aspiredMilestone == .focusAnimalRecognized && ratedFocusAnimal.confidence > 0.92{
                                self.userHasReachedMilestone(milestone: .focusAnimalRecognized)
                            }
                            
                            self.graph1.setPrediction(prediction: ratedFocusAnimal.confidence, for: ratedFocusAnimal.type)
                            
                        }
                        
                    } else {
                        
                        //no focus, show best three animals
                        self.graph1.setPrediction(prediction: results[0].confidence, for: results[0].type)
                        self.graph2.setPrediction(prediction: results[1].confidence, for: results[1].type)
                        self.graph3.setPrediction(prediction: results[2].confidence, for: results[2].type)
                        
                    }
                    
                }
            }
        }
        
        
    }
    
    internal func templateDrawingCompleted() {
        userHasReachedMilestone(milestone: .firstUseOfTeacher)
        
    }
    
}


public extension DrawingStudioViewController {
    public class func instantiateFromStoryboard() -> DrawingStudioViewController {
        let storyBoard = UIStoryboard(name: "LiveView", bundle: Bundle.main)
        let viewController = storyBoard.instantiateInitialViewController() as! DrawingStudioViewController
        
        return viewController
    }
}


