//
//  Recorder.swift
//  WWDC Scholarship 2019
//
//  Created by Stefan Liesendahl on 19.03.19.
//

import Foundation

public class Recorder {
    
    /// Possibility to start recording right after loading the page
    public var autoStart = false
    
    // MARK: Initialization
    public init() {}
}

